@file:OptIn(ExperimentalMaterial3Api::class)

package com.limonchik.escooter

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

const val TG_CHANNEL = "https://t.me/EscooterOfficial"
const val TG_BOT = "https://t.me/EScooterApp_bot"
const val TG_SUPPORT = "https://t.me/EScooterApp_bot?start=support"

@Suppress("DEPRECATION")
fun buzz(ctx: Context, ms: Long = 300) {
    try { (ctx.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator)?.vibrate(ms) } catch (_: Throwable) {}
}

fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
}

/** Opens the bot with a /start payload "<username>-<Model>" so START sends everything automatically. */
fun botLink(user: String, model: String): String {
    val u = user.trim().removePrefix("@").filter { it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == '_' }
    val m = model.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
    val p = (u + if (u.isNotEmpty() && m.isNotEmpty()) "-$m" else "").take(64)
    return if (p.isEmpty()) TG_BOT else "$TG_BOT?start=$p"
}

@Composable
fun Bg(content: @Composable ColumnScope.() -> Unit) {
    val c = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.background, c.surface)))
            .statusBarsPadding().navigationBarsPadding().padding(16.dp),
        content = content
    )
}

// ---------------- Onboarding ----------------
@Composable
fun Onboarding(vm: MainViewModel) {
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableIntStateOf(if (vm.userAsked) 1 else 0) }
    var sel by rememberSaveable { mutableStateOf(vm.scooter ?: "") }
    if (step == 0) BotStep(vm) { step = 1 }
    else PickerStep(sel, { sel = it }) {
        vm.setScooter(sel.trim())
        vm.finishOnboarding()
        vm.registerOnce(ctx)
    }
}

@Composable
fun BotStep(vm: MainViewModel, next: () -> Unit) {
    val c = MaterialTheme.colorScheme
    var u by rememberSaveable { mutableStateOf("") }
    Bg {
        Text("Добро пожаловать 👋", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Напишите в бот @EScooterApp_bot свой юзернейм и модель самоката — так мы поможем с подключением и добавим новые модели.", color = c.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(u, { u = it }, label = { Text("Ваш юзернейм Telegram") }, prefix = { Text("@") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = c.surfaceVariant), shape = RoundedCornerShape(16.dp)) {
            Text(
                "Как это работает:\n\n" +
                    "1. Введите юзернейм и нажмите «Далее».\n" +
                    "2. Выберите свой самокат.\n" +
                    "3. Откроется @EScooterApp_bot — нажмите START, юзернейм и модель отправятся автоматически.\n\n" +
                    "Можно и вручную: просто напишите боту свой @юзернейм и модель.",
                Modifier.padding(16.dp)
            )
        }
        Spacer(Modifier.weight(1f))
        Button({ vm.saveUser(u); next() }, enabled = u.isNotBlank(), modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Далее") }
        TextButton({ next() }, Modifier.fillMaxWidth()) { Text("Пропустить") }
    }
}

@Composable
fun PickerStep(sel: String, onSel: (String) -> Unit, onNext: () -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    var brand by rememberSaveable { mutableStateOf("Все") }
    var custom by rememberSaveable { mutableStateOf(false) }
    var customText by rememberSaveable { mutableStateOf("") }
    val list = Scooters.all.filter { (brand == "Все" || it.brand == brand) && it.name.contains(q, true) }
    val c = MaterialTheme.colorScheme
    Bg {
        Text("Выберите ваш самокат", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Так мы подберём настройки соединения", color = c.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(q, { q = it }, placeholder = { Text("Поиск модели") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Все", "Kugoo", "Ninebot", "Xiaomi").forEach {
                FilterChip(selected = brand == it, onClick = { brand = it }, label = { Text(it) })
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { s -> ModelCard(s.name, sel == s.name && !custom) { custom = false; onSel(s.name) } }
            item { ModelCard("✏️  Другой вариант", custom) { custom = true; onSel(customText) } }
        }
        if (custom) {
            OutlinedTextField(customText, { customText = it; onSel(it) }, label = { Text("Название вашего самоката") },
                singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        Spacer(Modifier.height(8.dp))
        Button(onNext, enabled = sel.isNotBlank(), modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Далее") }
    }
}

@Composable
fun ModelCard(title: String, on: Boolean, click: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Surface(
        onClick = click, shape = RoundedCornerShape(16.dp),
        color = if (on) c.primary.copy(alpha = .18f) else c.surfaceVariant,
        border = if (on) BorderStroke(2.dp, c.primary) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium)
            if (on) Text("✓", color = c.primary, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun FeatureCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = MaterialTheme.colorScheme
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = c.surfaceVariant), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

// ---------------- Main ----------------
@Composable
fun Dial(value: Float, max: Float, center: String, unit: String, color: Color, track: Color) {
    val anim by animateFloatAsState(value, tween(400), label = "dial")
    Box(Modifier.size(270.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 22.dp.toPx()
            val sz = Size(size.width - stroke, size.height - stroke)
            val tl = Offset(stroke / 2, stroke / 2)
            drawArc(track, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            val sweep = 270f * (anim / max).coerceIn(0f, 1f)
            if (sweep > 0.5f) drawArc(color, 135f, sweep, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(center, fontSize = 64.sp, fontWeight = FontWeight.Bold)
            Text(unit, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 16.sp)
        }
    }
}

@Composable
fun Stat(label: String, value: String, mod: Modifier) {
    val c = MaterialTheme.colorScheme
    Card(mod, colors = CardDefaults.cardColors(containerColor = c.surfaceVariant), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(label, color = c.onSurfaceVariant, fontSize = 12.sp)
        }
    }
}

@Composable
fun MainScreen(vm: MainViewModel, requestScan: () -> Unit) {
    val ctx = LocalContext.current
    val ble = vm.ble
    val st by ble.state.collectAsState()
    val t by ble.data.collectAsState()
    val noData by ble.noData.collectAsState()
    val protoOk by ble.protoOk.collectAsState()
    val light by ble.light.collectAsState()
    val locked by ble.locked.collectAsState()
    val msg by ble.msg.collectAsState()
    val info by ble.info.collectAsState()
    var settings by remember { mutableStateOf(false) }
    var diag by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var about by remember { mutableStateOf(false) }
    var confirmOff by remember { mutableStateOf(false) }
    val strobe by ble.strobe.collectAsState()
    val stats by ble.stats.collectAsState()
    val kers by ble.kers.collectAsState()
    val cruise by ble.cruise.collectAsState()
    val c = MaterialTheme.colorScheme
    val prof = profileFor(vm.scooter)
    val on = st == ConnState.CONNECTED
    val live = on && protoOk
    val parked = live && t.speed < 0.5f
    val spd = if (vm.mph) t.speed * 0.621371f else t.speed
    val k = if (vm.mph) 0.621371f else 1f
    val dist = if (vm.mph) "mi" else "km"
    val batColor = when { t.battery > 50 -> Color(0xFF4CD964); t.battery > 20 -> Color(0xFFFFC107); else -> Color(0xFFFF5252) }
    val status = when (st) {
        ConnState.IDLE -> "Не подключён"; ConnState.SCANNING -> "Поиск…"; ConnState.CONNECTING -> "Подключение…"
        ConnState.CONNECTED -> "Подключён"; ConnState.ERROR -> "Ошибка соединения"
    }
    val over = live && vm.speedAlert > 0 && t.speed > vm.speedAlert
    LaunchedEffect(over) { if (over) buzz(ctx) }
    val low = live && vm.lowAlert && t.battery in 1..15
    LaunchedEffect(low) { if (low) buzz(ctx, 700) }
    Bg {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("МОЙ САМОКАТ", color = c.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("🛴 ${vm.scooter ?: "—"}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
            Box {
                IconButton({ menu = true }) { Text("⋮", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Диагностика") }, { menu = false; diag = true })
                    DropdownMenuItem({ Text("Настройки") }, { menu = false; settings = true })
                    DropdownMenuItem({ Text("Связь с разработчиком") }, { menu = false; openUrl(ctx, TG_SUPPORT) })
                    DropdownMenuItem({ Text("Сменить самокат") }, { menu = false; vm.changeScooter() })
                    DropdownMenuItem({ Text("Telegram-канал") }, { menu = false; openUrl(ctx, TG_CHANNEL) })
                    DropdownMenuItem({ Text("О приложении") }, { menu = false; about = true })
                }
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(8.dp))
            AssistChip(onClick = {}, label = { Text(status) })
            Text(
                "Протокол: ${prof.family.title}" + if (info.fw.isNotEmpty()) " · FW ${info.fw}" else "",
                color = c.onSurfaceVariant, fontSize = 12.sp, textAlign = TextAlign.Center
            )
            if (msg.isNotEmpty()) Text(msg, color = c.onSurfaceVariant, fontSize = 13.sp, textAlign = TextAlign.Center)
            Dial(
                value = if (parked) t.battery.toFloat() else spd,
                max = if (parked) 100f else if (vm.mph) 25f else 40f,
                center = when { !live -> "--"; parked -> "${t.battery}"; else -> "%.0f".format(spd) },
                unit = when { !live -> ""; parked -> "% заряд"; vm.mph -> "mph"; else -> "km/h" },
                color = if (parked) batColor else c.primary, track = c.surfaceVariant
            )
            if (live) {
                LinearProgressIndicator({ t.battery / 100f }, Modifier.fillMaxWidth().height(8.dp),
                    color = batColor, trackColor = c.surfaceVariant)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stat("Поездка", "%.1f %s".format(t.trip * k, dist), Modifier.weight(1f))
                    Stat("Всего", "%.0f %s".format(t.total * k, dist), Modifier.weight(1f))
                    Stat("Темп.", "%.0f°C".format(t.temp), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val bm = Modifier.weight(1f).height(50.dp)
                    if (light) Button({ ble.setLight(false) }, bm) { Text("💡 Свет: вкл") }
                    else OutlinedButton({ ble.setLight(true) }, bm) { Text("💡 Свет") }
                    if (locked) Button({ ble.setLock(false) }, bm) { Text("🔒 Закрыт") }
                    else OutlinedButton({ ble.setLock(true) }, bm) { Text("🔓 Замок") }
                }
                Spacer(Modifier.height(12.dp))
                FeatureCard("⚡ Стробоскоп (фонарь)") {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StrobeMode.values().forEach { m ->
                            FilterChip(vm.strobeMode == m.ordinal, { vm.setStrobeMode(m.ordinal) }, { Text(m.title, fontSize = 12.sp) })
                        }
                    }
                    Text("Скорость мигания: ×%.1f".format(vm.strobeSpeed), fontSize = 12.sp, color = c.onSurfaceVariant)
                    Slider(vm.strobeSpeed, { vm.setStrobeSpeed(it) }, valueRange = 0.5f..2.5f)
                    if (strobe) Button({ ble.stopStrobe() }, Modifier.fillMaxWidth().height(48.dp)) { Text("⏹ Остановить") }
                    else Button({ ble.startStrobe(StrobeMode.values()[vm.strobeMode], 1f / vm.strobeSpeed) },
                        Modifier.fillMaxWidth().height(48.dp), enabled = parked) { Text("▶ Запустить") }
                    Text("Только на стоянке; при движении выключается сам.", fontSize = 11.sp, color = c.onSurfaceVariant)
                }
                Spacer(Modifier.height(8.dp))
                FeatureCard("🔋 Рекуперация и круиз") {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Слабая", "Средняя", "Сильная").forEachIndexed { i, n ->
                            FilterChip(kers == i, { ble.setKers(i) }, { Text(n, fontSize = 12.sp) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Круиз-контроль", Modifier.weight(1f)); Switch(cruise, { ble.setCruise(it) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                val avg = if (stats.n > 0) stats.sum / stats.n else 0f
                val mins = if (stats.startMs > 0) (System.currentTimeMillis() - stats.startMs) / 60000 else 0
                val su = if (vm.mph) "mph" else "км/ч"
                FeatureCard("📊 Статистика сессии") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Stat("Макс, $su", "%.1f".format(stats.max * k), Modifier.weight(1f))
                        Stat("Средняя, $su", "%.1f".format(avg * k), Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Stat("Время, мин", "$mins", Modifier.weight(1f))
                        Stat("Заряда израсходовано", "${(stats.startBat - t.battery).coerceAtLeast(0)}%", Modifier.weight(1f))
                    }
                }
                TextButton({ confirmOff = true }, Modifier.fillMaxWidth()) { Text("⏻ Выключить самокат", color = Color(0xFFFF5252)) }
                if (t.error != 0) Text("Код ошибки: ${t.error}", color = Color(0xFFFF5252), modifier = Modifier.padding(top = 8.dp))
            }
            if (on && !protoOk && !noData) Text("Ожидание ответа самоката…", color = c.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp))
            if (on && !protoOk && noData) Card(Modifier.padding(top = 12.dp), colors = CardDefaults.cardColors(containerColor = c.surfaceVariant)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Самокат подключён, но не отвечает на протокол M365/Ninebot G30. " +
                        "Управление (свет, замок) отключено, чтобы не слать команды вслепую.", fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(prof.family.note, fontSize = 13.sp, color = c.onSurfaceVariant)
                    TextButton({ diag = true }) { Text("Открыть диагностику") }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (on) OutlinedButton({ ble.disconnect() }, Modifier.fillMaxWidth().height(52.dp)) { Text("Отключить") }
        else Button(requestScan, Modifier.fillMaxWidth().height(52.dp)) { Text("Найти самокат") }
        Text("Автор: limonchik", Modifier.fillMaxWidth().padding(top = 6.dp), textAlign = TextAlign.Center,
            color = c.onSurfaceVariant, fontSize = 11.sp)
    }
    if (about) AboutDialog { about = false }
    if (confirmOff) AlertDialog(
        onDismissRequest = { confirmOff = false },
        title = { Text("Выключить самокат?") },
        text = { Text("Команда выключения уйдёт на самокат. Включить его можно только кнопкой.") },
        confirmButton = { TextButton({ confirmOff = false; ble.shutdown() }) { Text("Выключить", color = Color(0xFFFF5252)) } },
        dismissButton = { TextButton({ confirmOff = false }) { Text("Отмена") } }
    )
    if (settings) SettingsDialog(vm) { settings = false }
    if (diag) DiagnosticsDialog(vm) { diag = false }
}

@Composable
fun DiagnosticsDialog(vm: MainViewModel, close: () -> Unit) {
    val ctx = LocalContext.current
    val ble = vm.ble
    val st by ble.state.collectAsState()
    val proto by ble.protoOk.collectAsState()
    val bytes by ble.rawBytes.collectAsState()
    val info by ble.info.collectAsState()
    val gatt by ble.gattDump.collectAsState()
    val frames by ble.frames.collectAsState()
    val prof = profileFor(vm.scooter)
    val c = MaterialTheme.colorScheme
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = c.background) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Диагностика", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f))
                    TextButton(close) { Text("Закрыть") }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Самокат: ${vm.scooter ?: "—"}")
                    Text("Профиль: ${prof.family.title}")
                    Text("Состояние: $st")
                    Text("Протокол M365 отвечает: ${if (proto) "да" else "нет"}")
                    Text("Принято байт: $bytes")
                    if (info.fw.isNotEmpty()) Text("Прошивка: ${info.fw}")
                    if (info.serial.isNotEmpty()) Text("Серийный №: ${info.serial}")
                    Text(prof.family.note, color = c.onSurfaceVariant, fontSize = 13.sp)
                    Text("GATT-сервисы", fontWeight = FontWeight.Medium)
                    Text(gatt.joinToString("\n").ifEmpty { "—" }, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("Кадры (TX/RX)", fontWeight = FontWeight.Medium)
                    Text(frames.joinToString("\n").ifEmpty { "—" }, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ ble.clearFrames() }, Modifier.weight(1f).height(48.dp)) { Text("Очистить") }
                    Button({
                        try {
                            val i = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, ble.report(vm.scooter ?: "?", prof.family.title))
                            }
                            ctx.startActivity(Intent.createChooser(i, "Отправить отчёт").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (_: Exception) {}
                    }, Modifier.weight(1f).height(48.dp)) { Text("Поделиться отчётом") }
                }
            }
        }
    }
}

@Composable
fun ScanDialog(vm: MainViewModel) {
    val list by vm.ble.found.collectAsState()
    val st by vm.ble.state.collectAsState()
    val msg by vm.ble.msg.collectAsState()
    var all by remember { mutableStateOf(false) }
    val shown = list.filter { all || it.likely }
    AlertDialog(
        onDismissRequest = { vm.closeScan() },
        title = { Text("Выберите самокат") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(all, { all = it }); Text("  Показать все устройства", fontSize = 14.sp)
                }
                if (st == ConnState.SCANNING) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp))
                if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)
                if (shown.isEmpty()) Text("Ничего не найдено. Включите самокат и Bluetooth или нажмите «Показать все».", fontSize = 13.sp)
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(shown) { d ->
                        Row(Modifier.fillMaxWidth().clickable { vm.connect(d.addr) }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text((if (d.likely) "🛴 " else "") + d.name.ifBlank { "Без имени" } + (if (d.brand.isNotEmpty()) " · ${d.brand}" else ""), fontWeight = FontWeight.Medium)
                                Text(d.addr, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("${d.rssi} dBm", fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton({ vm.ble.startScan() }) { Text("Повторить") } },
        dismissButton = { TextButton({ vm.closeScan() }) { Text("Закрыть") } }
    )
}

@Composable
fun SettingsDialog(vm: MainViewModel, close: () -> Unit) {
    AlertDialog(
        onDismissRequest = close,
        title = { Text("Настройки") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Тема")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Система", "Светлая", "Тёмная").forEachIndexed { i, n ->
                        FilterChip(vm.theme == i, { vm.setTheme(i) }, { Text(n, fontSize = 12.sp) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Мили (mph)", Modifier.weight(1f)); Switch(vm.mph, { vm.setMph(it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Не гасить экран", Modifier.weight(1f)); Switch(vm.keepOn, { vm.setKeepOn(it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Вибро при заряде ≤15%", Modifier.weight(1f)); Switch(vm.lowAlert, { vm.setLowAlert(it) })
                }
                Text("Вибро при превышении скорости")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0, 15, 20, 25, 30).forEach { v ->
                        FilterChip(vm.speedAlert == v, { vm.setSpeedAlert(v) }, { Text(if (v == 0) "Выкл" else "$v", fontSize = 12.sp) })
                    }
                }
            }
        },
        confirmButton = { TextButton(close) { Text("Готово") } }
    )
}

@Composable
fun AboutDialog(close: () -> Unit) {
    val ctx = LocalContext.current
    val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Throwable) { "" }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("E-scooter App $ver") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Автор: limonchik", fontWeight = FontWeight.Bold)
                Text("Управление и диагностика электросамокатов по Bluetooth LE.", fontSize = 13.sp)
                OutlinedButton({ openUrl(ctx, TG_SUPPORT) }, Modifier.fillMaxWidth()) { Text("✉️ Связь с разработчиком") }
                OutlinedButton({ openUrl(ctx, TG_CHANNEL) }, Modifier.fillMaxWidth()) { Text("📢 Канал @EscooterOfficial") }
            }
        },
        confirmButton = { TextButton(close) { Text("Закрыть") } }
    )
}

@Composable
fun TgDialog(vm: MainViewModel) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = { vm.dismissTg() },
        title = { Text("Подпишитесь на канал 📢") },
        text = { Text("Новости, обновления и советы — в Telegram-канале @EscooterOfficial") },
        confirmButton = { Button({ openUrl(ctx, TG_CHANNEL); vm.dismissTg() }) { Text("Подписаться") } },
        dismissButton = { TextButton({ vm.dismissTg() }) { Text("Позже") } }
    )
}
